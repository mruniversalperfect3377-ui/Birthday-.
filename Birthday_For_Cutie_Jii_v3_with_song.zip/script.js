const $ = s => document.querySelector(s);

document.querySelectorAll("[data-scroll]").forEach(btn=>{
  btn.addEventListener("click",()=>document.querySelector(btn.dataset.scroll)?.scrollIntoView({behavior:"smooth"}));
});

const particles = $("#particles");
for(let i=0;i<26;i++){
  const p=document.createElement("span");
  p.className="particle";
  p.style.left=Math.random()*100+"%";
  p.style.animationDelay=(-Math.random()*8)+"s";
  p.style.animationDuration=(6+Math.random()*7)+"s";
  particles.appendChild(p);
}

$("#blowCandles").addEventListener("click",()=>{
  document.querySelector(".cake-wrap").classList.add("off");
  $("#candleHint").textContent="Wish made. ✨";
  $("#cakeReveal").classList.add("show");
  confetti();
});

function confetti(){
  for(let i=0;i<32;i++){
    const p=document.createElement("span");
    p.className="particle";
    p.style.left=(35+Math.random()*30)+"%";
    p.style.top=(35+Math.random()*15)+"%";
    p.style.animation="none";
    p.style.opacity=".9";
    p.style.width=p.style.height=(4+Math.random()*5)+"px";
    p.style.transform=`translate(${(Math.random()-.5)*280}px, ${(Math.random()-.5)*180}px)`;
    particles.appendChild(p);
    setTimeout(()=>p.remove(),1100);
  }
}

$("#cowTrigger").addEventListener("click",()=>{
  $("#cowReveal").classList.add("show");
  $("#cowTrigger").style.display="none";
});

$("#openLetter").addEventListener("click",()=>{
  $("#envelope").classList.toggle("open");
});

$("#openGift").addEventListener("click",()=>{
  $("#gift").classList.add("open");
  $("#giftMessage").classList.add("show");
  confetti();
});

const song=$("#song"), musicBtn=$("#musicBtn");
musicBtn.addEventListener("click",()=>{
  if(song.paused){
    song.play().then(()=>musicBtn.textContent="❚❚ Pause our song 🎵").catch(()=>{
      musicBtn.textContent="Tap again to play 🎵";
    });
  }else{
    song.pause();
    musicBtn.textContent="▶ Play our song 🎵";
  }
});
